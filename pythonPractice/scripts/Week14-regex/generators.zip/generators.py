#Processing with generators vs. list processing

'''Generator better for performance on largers data sets
doesn't hold all values in memory like a list
(yields only 1 (object) value at a time)'''

'list vers'
'''
def square_numbers(nums):
    result = []
    for i in nums:
        result.append(i*i)
    return result

my_nums = square_numbers([1,2,3,4,5])

print("List processing:->", my_nums) # [1, 4, 9, 16, 25]
'''

'generator vers' 
def square_numbers(nums):
    for i in nums:
        yield (i*i) #makes a generator in memory to yield one value at a time
        
my_nums = square_numbers([1,2,3,4,5])

'Alternative list comprehension method vs. method creation'
#my_nums = [x*x for x in [1,2,3,4,5]]

print("\nGenerator processing")
'''use built-in python function next() to retriever iterator value''' 
print(next(my_nums))  #1  ... Yielding 1 value at a time
print(next(my_nums))  #4
print(next(my_nums))  #9
print(next(my_nums))  #16
print(next(my_nums))  #25

'adding 1 more print method yields StopIteration exception'
#print(next(my_nums))

'Alternative and safer printing' 
#for num in my_nums:
    #print (num)

'Alternative to list comp. add parenthesis to make a generator'
my_nums = (x*x for x in [1,2,3,4,5])
print(list(my_nums)) # casting generator to list loses performance gain




