import random
import time,os
import psutil

'''*************************************************************
Note to import modules not on your system use the following
use Pip (Pip installs Python) package management systme 
cli commands for Pip install if necessary:
mac os / linux : sudo easy_install pip
windows: python -m pip install -U pip setuptools

then to load modules
just do
pip install psutil or ...
pip3 install psutil
*************************************************************'''

pid = os.getpid()
py = psutil.Process(pid)
memoryUse = py.memory_info()[0]/float(2**20)  # memory use in MB

print('MB memory use:', memoryUse)

names = ['John', 'Corey', 'Adam', 'Steve', 'Rick', 'Thomas']
majors = ['Math', 'Engineering', 'CompSci', 'Arts', 'Business']

def people_list(num_people):
    result = []
    for i in range(num_people):
        person = {
                    'id': i,
                    'name': random.choice(names),
                    'major': random.choice(majors)
                }
        result.append(person)
    return result

def people_generator(num_people):
    for i in range(num_people):
        person = {
                    'id': i,
                    'name': random.choice(names),
                    'major': random.choice(majors)
                }
        yield person

t1 = time.clock()  #checks against actual program time execution
people = people_list(1000000)
t2 = time.clock()
'''
t1 = time.clock()
people = people_generator(1000000)
t2 = time.clock()
'''
print()

memoryUse = py.memory_info()[0]/float(2**20)  # memory use in MB
print('MB memory use:', memoryUse)

print ('\nTook {} Seconds'.format(t2-t1))
