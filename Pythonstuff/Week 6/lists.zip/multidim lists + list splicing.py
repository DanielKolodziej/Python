myList = [1,2,3,4]
print (myList)

print (myList[:])

myList=[]
print (myList)

print()

newList = [5,1,2,3,4]
#splice up lists
print (newList[:2])
print (newList[1:])
print (newList[0:2])
print (newList[0:-2])
print (newList[-1:2])

print()

listVals  = [[2,3,4],5,6];
#listVals [0]=0;
listVals [0][1]=50;
print (listVals[0])
