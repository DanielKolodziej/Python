
## Split methods ex 1
'''
***************************************************************************
format: str.split([sep[,maxsplit]])

Per docs- Return a list of the words in the string, using sep as the delimiter string.
If maxsplit is given, at most maxsplit splits are done (thus, the list will
have at most maxsplit+1 elements).
***************************************************************************
'''

str = "Line1-abcdef \nLine2-abc \nLine4-abcd";
print()
print (str.split( ));
print()
print (str.split(' ', 2 ));  
print (str.split(' ', 2 )[1]);

print()

'''

#ex 2
x = 'blue,red,green'
splitter= x.split(",")

print(splitter[0])

a,b,c = x.split(",")
print(a,b,c)

'''
'''
print()

#ex 3
word = "This is some random text"

words2 = word.split(" ")

print(words2)

print()

'''

# join method ex 4
'''
************************************************************
format: str.join(sequence)

join inserts the seperator between the elements of the array
can be seen as the 'inverse' of the split() method
************************************************************
'''
'''
# ex 1
print (",".join(["a", "b", "c"]))

str = "-";
seq = ("a", "b", "c"); # This is sequence of strings.
print (str.join( seq ));

# ex 2

strid = repr(595)  #Returns string containing a printable representation of an object.

print (",".join(strid));  #note the represented outcome as a "list" of string values

strid=[5,9,5];
print (",".join(strid)) #throws error! Why?

'''
'''
#ex 3
'''
#format: str.strip([chars]);
'''
print()

str = "0000000this is string example....wow!!!0000000";

print (str.strip( '0' ));
'''








