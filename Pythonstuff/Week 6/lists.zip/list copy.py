list1=["hi","bye"]
list2=[]
list2=list1
list2[0]="hello"
list1[1]="goodbye"
list2.append("foo")
print(list1)
print(list2)
