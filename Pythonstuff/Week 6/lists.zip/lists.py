###*******List data structure scripts***********###

##1. Bank Account - accumulate bank balance
def bank_list():
    list=[12000.32,2100.46,603.32]
    return list

l=bank_list()

#Slices. Print first 2 items in list
print (l[:2])
#or print(l[-3:-1])

#Print alternative indicies (values) in list, use step option
print(l[0:3:2])

'''

##2. accumulate / display bank balance 
l = sorted(l)
total = 0
for item in l:
    total += item 
print("%s Balance: $%s" %(l,total))
'''

'''
##3. print lists of stock information by class ranking
#format of list item [stock sym, stock rank, stock class]
stockList = [["aapl", 2, "a"], ["alph", 5, "b"], ["goog", 4, "d"]]
stockList.sort(key=lambda x: x[0]) #sort by value of key applied to each list element
print (stockList)

'''
'''
##4. List of Lists
def getKey(item):
    return item[1]

a = [[2, 3], [6, 7], [3, 34], [24, 64], [44, 43]]
a.sort(key=getKey) #iterate thru list and sort by first index per element
print(a)

'''
'''
##5. Reverse sort
rev=sorted(a,reverse=True)
print(rev)

'''
'''

##6. List of Tuples
students = [
        ('john', 'A', 15),
        ('jane', 'B', 12),
        ('dave', 'B', 10),
]
students.sort(key=lambda students: students[2])   # sort by age
print(students)

'''
'''

##7. List complexities
#Sort list (l) below by number (highest to lowest) then by letter (ascending order)

l = [('f', 4), ('b', 4), ('a', 3), ('c', 6), ('k', 1)]
l.sort(key=lambda x:(-x[1],x[0]))
print(l)

#solution: Pass two keys to sort, -x[1] which reverses the sort by numbers with
#the negative sign from highest to lowest, we then break ties with x[0] which
#is sorted from lowest to highest i.e a-z naturally.

'''
'''





