'''Stack (LIFO) example'''

stack = [3, 4, 5]
stack.append(7)  #push item onto stack
print("Original stack:\t",stack)
newStack = stack.pop() #pop last item from stack
print("Popped item=>   ",newStack)
print("New stack:\t",stack)

print()

'''Queue (FIFO) Example'''

queue = [3, 4, 5]
queue.append(7) #add item to rear of queue
print("Original queue:\t",queue)
newQueue = queue.pop(0) #pop first item from queue
print("Removed item=>  ",newQueue)
print("Revised queue:\t",queue)
