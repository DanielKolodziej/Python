
## List Comprehensions

#ex 1
squares = []
for x in range(10):
    squares.append(x**2)
print (squares)

#equivalent with list comps
squares = [x**2 for x in range(10)]
print ('\n%s' % squares)

print()


#ex 2 - Create List of Tuples
list =[(x, y) for x in [1,2,3] for y in [3,1,4] if x != y]
print (list)

#equivalent old school coding
combos = []
for x in [1,2,3]:
    for y in [3,1,4]:
        if x != y:
            combos.append((x, y))  #grab tuples in a list, shown as parenthesized
print ('\n%s' % combos)   #print tuples

print()

#ex3 
vecVals = [-4, -2, 0, 2, 4]
# create a new list with the values doubled
list=[x*2 for x in vecVals]
print (list)
print()
# filter the list to exclude negative numbers
print ([x for x in vecVals if x >= 0])




